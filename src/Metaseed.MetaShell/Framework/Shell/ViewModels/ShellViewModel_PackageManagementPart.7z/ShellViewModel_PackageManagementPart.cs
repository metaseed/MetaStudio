﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections.ObjectModel;
using Catel.MVVM;
using System.IO;
using System.Windows;
using System.Windows.Input;
//using Microsoft.Practices.Prism.Events;
using Microsoft.Practices.Prism.Commands;
using Microsoft.Practices.Prism.Regions;
using System.Windows.Controls.Primitives;
using System.Collections.Specialized;
using System.IO.Packaging;
using System.Net.Mime;

using Catel.Logging;
using Catel.IoC;
using System.Reflection;
using Catel.Data;
using Xceed.Wpf.AvalonDock;
using Xceed.Wpf.AvalonDock.Layout;
using Xceed.Wpf.AvalonDock.Layout.Serialization;

using System.Globalization;
using Catel;
using System.Windows.Data;
using System.ComponentModel;
using Catel.Messaging;
using Catel.MVVM.Services;
namespace Metaseed.MetaShell.ViewModels
{
    using Views;
    using Services;
    using Infrastructure;
    using Properties;
    using Metaseed.Collections.Generic;
    using Metaseed.Data;
    using Metaseed.Windows.Controls;
    using Metaseed.Windows.Interop;
    using Metaseed.Collections.Generic;
    using Metaseed.Reflection;
    /// <summary>
    /// Shell view model.
    /// </summary>
    public partial class ShellViewModel : MetaViewModel
    {
        #region Fields
        public static string Package_PanelLayoutPart_ID = "PanelLayoutID";
        public static string Package_PanelLayoutPart_Path = "/PanelLayout.xml";
        public static string Package_DocumentsUnopen_ID = "DocumentsUnopenID";
        public static string Package_DocumentsUnopen_Path = "/DocumentsUnopen.xml";


        #endregion

        #region Constructors
        /// <summary>
        /// Initializes a new instance of the <see cref="ShellViewModel"/> class.
        /// </summary>
        private void ShellViewModel_PackageManagementPart()
        {

            NewCommand = new DelegateCommand(NewCommand_Executed);
            GloableCommands.NewCommand.RegisterCommand(NewCommand);
            OpenCommand = new DelegateCommand(Open_Executed);
            SaveCommand = new DelegateCommand(Save_Executed, Save_CanExecuted);
            SaveAsCommand = new DelegateCommand(SaveAs_Executed);

            DelDocumentCommand = new Command<IPackageContent, IPackageContent>(OnDelDocumentCommandExecute, OnDelDocumentCommandCanExecute);
            OpenDocumentCommand = new Command<IPackageContent, IPackageContent>(OnOpenDocumentCommandExecute, OnOpenDocumentCommandCanExecute);
            SaveDocumentCommand = new Command<IPackageContent, IPackageContent>(OnSaveDocumentCommandExecute, OnSaveDocumentCommandCanExecute);
            SaveCurrentDocumentCommand = new Command(OnSaveCurrentDocumentCommandExecute, OnSaveCurrentDocumentCommandCanExecute);

            this.GetDependencyResolver().Resolve<IExceptionHandler>().SaveOnException += ShellViewModel_SaveOnException;
        }

        void ShellViewModel_SaveOnException(object sender, EventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(CurrentPackagePath))
            {
                string filePath = CurrentPackagePath + ".BackupOnException.conc";
                Save(filePath);
                MessageBox.Show("Your Configuration Data Has Been Saved To File:" + filePath, "Save Your Data", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }
        #endregion

        #region Properties
        string _currentPackagePath;
        public string CurrentPackagePath
        {
            get { return _currentPackagePath; }
            set
            {
                if (value != _currentPackagePath)
                {
                    _currentPackagePath = value;
                    ((DelegateCommand)SaveCommand).RaiseCanExecuteChanged();
                    RaisePropertyChanged(() => this.CurrentPackagePath);
                    TruncatedPackagePath = TruncateFilePath.TruncatePath(_currentPackagePath, 40);
                }
            }
        }
        int recentFileNumber = 20;
        void addToRecentFiles(string fileName)
        {
            if (RecentFiles.Contains(fileName))
            {
                RecentFiles.Remove(fileName);
                InterestedAppSettings.RecentFiles.Remove(fileName);
                RecentFiles.Insert(0, fileName);
                InterestedAppSettings.RecentFiles.Insert(0, fileName);
            }
            else
            {
                if (RecentFiles.Count >= recentFileNumber)
                {
                    RecentFiles.RemoveAt(recentFileNumber - 1);
                    InterestedAppSettings.RecentFiles.RemoveAt(recentFileNumber - 1);
                }
                RecentFiles.Insert(0, fileName);
                InterestedAppSettings.RecentFiles.Insert(0, fileName);
            }
        }
        ObservableCollection<string> _RecentFiles = new ObservableCollection<string>();
        public ObservableCollection<String> RecentFiles
        {
            get
            {
                if (InterestedAppSettings.RecentFiles == null)
                {
                    InterestedAppSettings.RecentFiles = new StringCollection();
                    return _RecentFiles;
                }
                else
                {
                    _RecentFiles.Clear();
                    foreach (var item in InterestedAppSettings.RecentFiles)
                    {
                        _RecentFiles.Add(item);
                    }
                    return _RecentFiles;
                }
            }
        }
        // TODO: Register models with the vmpropmodel codesnippet
        // TODO: Register view model properties with the vmprop or vmpropviewmodeltomodel codesnippets
        #endregion

        #region Commands
        // TODO: Register commands with the vmcommand or vmcommandwithcanexecute codesnippets
        public ICommand NewCommand { get; private set; }
        public ICommand OpenCommand { get; private set; }
        public ICommand SaveCommand { get; private set; }
        public ICommand SaveAsCommand { get; private set; }
        public Command<IPackageContent, IPackageContent> DelDocumentCommand { get; private set; }
        public Command<IPackageContent, IPackageContent> OpenDocumentCommand { get; private set; }
        public Command<IPackageContent, IPackageContent> SaveDocumentCommand { get; private set; }
        public Command SaveCurrentDocumentCommand { get; private set; }
        #endregion

        #region Methods
        #region private methods

        public void NewCommand_Executed()
        {

        }
        public void Open_Executed()
        {
            IOpenFileService openFileService = this.GetDependencyResolver().Resolve<IOpenFileService>();
            openFileService.AddExtension = true;
            openFileService.CheckFileExists = true;
            openFileService.CheckPathExists = true;
            openFileService.Filter = "MetaStudio Package File(*.meta)|*.meta|All (*.*)|*.*";
            openFileService.FilterIndex = 0;
            if (string.IsNullOrEmpty(CurrentPackagePath))
            {
                if (RecentFiles.Count > 0 && File.Exists(RecentFiles[0]))
                {
                    openFileService.InitialDirectory = RecentFiles[0];
                }
                else
                {
                    openFileService.InitialDirectory = System.Environment.GetFolderPath(System.Environment.SpecialFolder.MyDocuments);
                }
            }
            else
            {
                openFileService.InitialDirectory = CurrentPackagePath;
            }

            openFileService.Title = Resources.OpenFileDialogTitle;
            var bFile = openFileService.DetermineFile();
            if (bFile)
            {
                Open(openFileService.FileName);
            }

        }
        bool Save_CanExecuted()
        {
            if (string.IsNullOrEmpty(CurrentPackagePath))
            {
                return false;
            }
            else
            {
                return true;
            }
        }
        void safeSave()
        {
            if (File.Exists(CurrentPackagePath + ".backup"))
            {
                File.Delete(CurrentPackagePath + ".backup");
            }
            if (File.Exists(CurrentPackagePath))//save :exist;saveas :not exist
            {
                var backupSaveFilePath = CurrentPackagePath + ".backup";
                File.Copy(CurrentPackagePath, backupSaveFilePath);
                File.Delete(CurrentPackagePath);
            }

            Save(CurrentPackagePath);
            if (File.Exists(CurrentPackagePath + ".backup"))
            {
                File.Delete(CurrentPackagePath + ".backup");
            }
        }
        void Save_Executed()
        {
            ShellService.Messager.WaitMessage.Show(Resources.SaveMessage);
            GloableStaticInstanse.StopWatch.Restart();
            GloableStaticInstanse.AppStatus = AppStatus.SavingPackage;
            safeSave();
            GloableStaticInstanse.AppStatus = AppStatus.Running; ;
            GloableStaticInstanse.StopWatch.Stop();
            ShellService.Messager.WaitMessage.Hide();
            Log.Info(Resources.FileSaveTimeFormat, GloableStaticInstanse.StopWatch.ElapsedMilliseconds);
        }
        void SaveAs_Executed()
        {
            ISaveFileService saveFileService = this.GetDependencyResolver().Resolve<ISaveFileService>();
            saveFileService.AddExtension = true;
            saveFileService.CheckFileExists = true;
            saveFileService.CheckPathExists = true;
            saveFileService.Filter = "MetaStudio Package File(*.meta)|*.meta|All (*.*)|*.*";
            saveFileService.FilterIndex = 0;
            saveFileService.InitialDirectory = string.IsNullOrEmpty(CurrentPackagePath) ? System.Environment.GetFolderPath(System.Environment.SpecialFolder.MyDocuments) : CurrentPackagePath;
            saveFileService.Title = Resources.SaveFileDialogTitle;
            var bFile = saveFileService.DetermineFile();
            if (bFile)
            {
                if (!string.IsNullOrEmpty(CurrentPackagePath))
                {
                    File.Copy(CurrentPackagePath, saveFileService.FileName);
                }
                CurrentPackagePath = saveFileService.FileName;
                Save_Executed();
            }
        }


        private void OnDelDocumentCommandExecute(IPackageContent document)
        {
            if (document is IDocumentViewModel)
            {
                var d = document as IDocumentViewModel;
                ShellService.CloseDocument(d);
            }
            using (Package package = Package.Open(CurrentPackagePath, FileMode.Open))
            {
                document.OnBeforeDelFromPackage();
                DeletePackageContent(package, document.ContentId);
            }
        }
        private bool OnDelDocumentCommandCanExecute(IPackageContent document)
        {
            if (string.IsNullOrEmpty(CurrentPackagePath))
            {
                return false;
            }
            return true;
        }
        private void OnOpenDocumentCommandExecute(IPackageContent document)
        {
            if (document is DocumentUnopen)
            {
                using (Package package = Package.Open(CurrentPackagePath, FileMode.Open))
                {
                    var documentViewMoel = OpenPackageContent(package, document.ContentId) as DocumentViewModel;
                    ShellService.OpenDocument(documentViewMoel);
                    ShellService.ActivateDocument(documentViewMoel);
                }
                ((ShellService)ShellService).DocumentsUnopen.Remove(document as DocumentUnopen);
            }
            else
            {
                ShellService.ActivateDocument(document as IDocumentViewModel);
            }

        }

        private bool OnOpenDocumentCommandCanExecute(IPackageContent document)
        {
            if (document is DocumentUnopen)
            {
                if (string.IsNullOrEmpty(CurrentPackagePath))
                {
                    return false;
                }
            }
            return true;
        }

        private void OnSaveDocumentCommandExecute(IPackageContent document)
        {
            if (document is ILayoutContentViewModel)
            {
                using (Package package = Package.Open(CurrentPackagePath, FileMode.Open))
                {
                    SavePackageContent(package, document as ILayoutContentViewModel);
                }
                var layoutContentViewModel = document as ILayoutContentViewModel;
                Log.Info("'" + layoutContentViewModel.Title + "'" + Properties.Resources.FileSavedMessage);
                this.ShellService.Messager.Balloon.ShowCustomBalloon(PopupAnimation.Fade, 3000, layoutContentViewModel.Title, Properties.Resources.FileSavedMessage, BalloonIcon.Info);
            }

        }
        private bool OnSaveDocumentCommandCanExecute(IPackageContent document)
        {
            if (string.IsNullOrEmpty(CurrentPackagePath))
            {
                return false;
            }
            if (document is ILayoutContentViewModel)
            {
                var d = document as ViewModelBase;
                if (d.IsDirty)
                {
                    return true;
                }
            }
            return false;
        }

        private void OnSaveCurrentDocumentCommandExecute()
        {

            using (Package package = Package.Open(CurrentPackagePath, FileMode.Open))
            {
                SavePackageContent(package, ShellService.ActiveDocument);
            }
            var layoutContentViewModel = ShellService.ActiveDocument;
            Log.Info("'" + layoutContentViewModel.Title + "'" + Properties.Resources.FileSavedMessage);
            this.ShellService.Messager.Balloon.ShowCustomBalloon(PopupAnimation.Fade, 3000, layoutContentViewModel.Title, Properties.Resources.FileSavedMessage, BalloonIcon.Info);
        }
        private bool OnSaveCurrentDocumentCommandCanExecute()
        {
            if (string.IsNullOrEmpty(CurrentPackagePath))
            {
                return false;
            }
            if (ShellService.ActiveDocument != null)
            {
                if (((ShellService.ActiveDocument) as ViewModelBase).IsDirty)
                {
                    return true;
                }
            }

            return false;
        }
        void OpenPackage(string packageFilePath)
        {
            if (!File.Exists(packageFilePath))
            {
                Log.Error("File Not Exist!");
                return;
            }

            using (Package package = Package.Open(packageFilePath, FileMode.Open))
            {
                //_EventAggregator.GetEvent<PackageBeforeOpenEvent>().Publish(package);
                PackageBeforeOpenEvent.SendWith(package);
                //load documents unopen
                var packageRelationShipDocumentsUnopen = package.GetRelationship(Package_DocumentsUnopen_ID);
                var layoutPartDocumentsUnopen = package.GetPart(packageRelationShipDocumentsUnopen.TargetUri);
                var xmlSerilalizer = new System.Xml.Serialization.XmlSerializer(typeof(ObservableCollection<DocumentUnopen>));
                var unopenDocs = xmlSerilalizer.Deserialize(layoutPartDocumentsUnopen.GetStream()) as ObservableCollection<DocumentUnopen>;
                foreach (var item in unopenDocs)
                {
                    ((ShellService)(ShellService)).DocumentsUnopen.Add(item);
                }

                //load avalondock panel layout
                var layoutRelationShip = package.GetRelationship(Package_PanelLayoutPart_ID);
                var layoutPart = package.GetPart(layoutRelationShip.TargetUri);
                DockingManager packageManger = this.GetDependencyResolver().Resolve<DockingManager>();
                var layoutSerializer = new XmlLayoutSerializer(packageManger);
                layoutSerializer.LayoutSerializationCallback += (s, e) =>
                {
                    //Get LayoutContentViewModel From Package
                    var contentViewModel = OpenPackageContent(package, e.Model.ContentId);
                    e.Content = contentViewModel;
                    var toolViewModel = contentViewModel as IToolViewModel;
                    var layoutAnchorable = e.Model as LayoutAnchorable;
                    if (toolViewModel != null && layoutAnchorable != null)
                    {
                        if (!ShellService.Tools.Contains_CompareByReference(toolViewModel))
                        {
                            ShellService.Tools.Add(toolViewModel);
                        }
                        toolViewModel.IsSelected = layoutAnchorable.IsSelected;
                        toolViewModel.IsActive = layoutAnchorable.IsActive;
                        toolViewModel.IsVisible = layoutAnchorable.IsVisible;
                        System.Diagnostics.Debug.Assert(ShellService.Documents.Count == 0);//the code of the avalondock behave in this kind of behavior, and the whole application assume the tools are loaded first.
                        return;
                    }
                    var documentViewModel = contentViewModel as IDocumentViewModel;
                    var layoutDocument = e.Model as LayoutDocument;
                    if (documentViewModel != null && layoutDocument != null)
                    {
                        if (!ShellService.Documents.Contains_CompareByReference(documentViewModel))
                        {
                            ShellService.Documents.Add(documentViewModel);
                        }
                        documentViewModel.IsSelected = layoutDocument.IsSelected;
                        documentViewModel.IsActive = layoutDocument.IsActive;
                        return;
                    }
                    return;
                };

                layoutSerializer.Deserialize(layoutPart.GetStream());
                //_EventAggregator.GetEvent<PackageAfterOpenEvent>().Publish(package);
                PackageAfterOpenEvent.SendWith(package);
            }
        }
        void SavePackage(string packageFilePath)
        {
            //(ShellService.Documents as ObservableCollection_Sortable<IDocumentViewModel>).Sort(d => {
            //    return d.GetType().GetAttributeValue((OrderAttribute a) => a.Value);
            //});
            //((ShellService)ShellService).DocumentsUnopen.Sort(d => d.TitleText);
            using (Package package = Package.Open(packageFilePath, FileMode.OpenOrCreate, FileAccess.ReadWrite))
            {
                //_EventAggregator.GetEvent<PackageSaveEvent>().Publish(package);
                PackageSaveEvent.SendWith(package);
                //save unopendocuments  
                Uri partUriDocumentsUnopen = PackUriHelper.CreatePartUri(new Uri(Package_DocumentsUnopen_Path, UriKind.Relative));
                PackagePart packagePartDocumentsUnopen = package.CreatePart(partUriDocumentsUnopen, MediaTypeNames.Text.Xml, CompressionOption.Normal);
                var packageRelationShipDocumentsUnopen = package.CreateRelationship(packagePartDocumentsUnopen.Uri, TargetMode.Internal, "DocumentsUnopen", Package_DocumentsUnopen_ID);
                var xmlSerilalizer = new System.Xml.Serialization.XmlSerializer(typeof(ObservableCollection<DocumentUnopen>));
                xmlSerilalizer.Serialize(packagePartDocumentsUnopen.GetStream(), ((ShellService)ShellService).DocumentsUnopen);
                //save avalondock panel layout
                Uri partUriDocument = PackUriHelper.CreatePartUri(new Uri(Package_PanelLayoutPart_Path, UriKind.Relative));
                PackagePart packagePartPanelLayout = package.CreatePart(partUriDocument, MediaTypeNames.Text.Xml, CompressionOption.Normal);
                var layoutRelationShip = package.CreateRelationship(packagePartPanelLayout.Uri, TargetMode.Internal, "AvalonDockPanelLayout", Package_PanelLayoutPart_ID);
                DockingManager packageManger = this.GetDependencyResolver().Resolve<DockingManager>();
                var layoutSerializer = new XmlLayoutSerializer(packageManger);
                layoutSerializer.Serialize(packagePartPanelLayout.GetStream());
                //save documents and tools
                IEnumerable<ILayoutContentViewModel> layoutContentViewModels = ShellService.Documents.Concat<ILayoutContentViewModel>(ShellService.Tools);
                foreach (var layoutContentViewModel in layoutContentViewModels)
                {
                    //Put LayoutContentViewModel To Package
                    SavePackageContent(package, layoutContentViewModel);
                }

            }
        }
        void OpenMetaFile(string fileName)
        {
            if (!string.IsNullOrEmpty(CurrentPackagePath))
            {
                GloableCommands.NewCommand.Execute(null);
            }
            if (GloableStaticInstanse.AppStatus!=AppStatus.StaringAndOpeningPackage)
            {
                GloableStaticInstanse.AppStatus = AppStatus.OpeningPackage;
            }
            string openMessage = Resources.OpenMessage;
            bool measureTime = false;
            if (!GloableStaticInstanse.StopWatch.IsRunning)
            {
                GloableStaticInstanse.StopWatch.Restart();
                measureTime = true;
            }
            CurrentPackagePath = fileName;
            ShellService.Messager.WaitMessage.Show(openMessage);
            NewCommand_Executed();
            ShellService.Clear();
           // try
            {
                OpenPackage(fileName);
                addToRecentFiles(fileName);
            }

            //catch (Exception e1)
            //{
            //    MessageBox.Show("Could not Open File: " + e1.Message + e1.StackTrace);
            //    ExceptionMessage.ShowExceptionMessage(e1);
            //}
           // finally
            {
                try
                {
                    ShellService.Messager.WaitMessage.Hide();
                }
                catch (Exception)
                {
                }
                
            }
            if (measureTime)
            {
                string message = string.Format(Properties.Resources.FileOpenTimeFormat, GloableStaticInstanse.StopWatch.ElapsedMilliseconds);
                Log.Info(message);
            }
            if (GloableStaticInstanse.AppStatus != AppStatus.StaringAndOpeningPackage)
            {
                GloableStaticInstanse.AppStatus = AppStatus.Running ;
            }
        }
        #endregion private methods

        private ILayoutContentViewModel OpenPackageContent(Package package, string contentID)
        {
            var contentID_Splits = contentID.Split(new string[] { "-_-" }, StringSplitOptions.RemoveEmptyEntries);
            System.Diagnostics.Debug.Assert(contentID_Splits.Length == 2);
            string packagePartTypeString = contentID_Splits[0];
            string packagePartID = contentID_Splits[1].Substring(0, 38);
            Type packagePartType = Type.GetType(packagePartTypeString);
            var packageRelationshipOfContentViewModel = package.GetRelationship(packagePartID);
            var packagePartOfContentViewModel = package.GetPart(packageRelationshipOfContentViewModel.TargetUri);
            //ILayoutContentViewModel contentViewModel = (ILayoutContentViewModel)typeof(ModelBase).GetMethod("Load", new Type[] { typeof(Stream), typeof(SerializationMode), typeof(bool) }).MakeGenericMethod(packagePartType).Invoke(null, new object[] { packagePartOfContentViewModel.GetStream(), SerializationMode.Xml, false });
            ILayoutContentViewModel contentViewModel = Load(packagePartType, packagePartOfContentViewModel.GetStream(), SerializationMode.Xml) as ILayoutContentViewModel;
            contentViewModel.ContentId = contentID;
            return contentViewModel;
        }
        private void DeletePackageContent(Package package, string contentID)
        {
            var contentID_Splits = contentID.Split(new string[] { "-_-" }, StringSplitOptions.RemoveEmptyEntries);
            System.Diagnostics.Debug.Assert(contentID_Splits.Length == 2);
            string packagePartTypeString = contentID_Splits[0];
            string packagePartID = contentID_Splits[1].Substring(0,38);
            Type packagePartType = Type.GetType(packagePartTypeString);
            var packageRelationshipOfContentViewModel = package.GetRelationship(packagePartID);
            package.DeletePart(packageRelationshipOfContentViewModel.TargetUri);
            package.DeleteRelationship(packagePartID);

        }
        private static void SavePackageContent(Package package, ILayoutContentViewModel layoutContentViewModel)
        {
            var pluginAssembleName = layoutContentViewModel.GetType().Assembly.GetName().Name;
            var LayoutContentViewModelPackagePartPath = "/" + pluginAssembleName + "/" + layoutContentViewModel.PackagePartName + ".xml";
            Uri partUriLayoutContentViewModel = PackUriHelper.CreatePartUri(new Uri(LayoutContentViewModelPackagePartPath, UriKind.Relative));
            if (package.PartExists(partUriLayoutContentViewModel))
            {
                package.DeletePart(partUriLayoutContentViewModel);
            }
            PackagePart packagePartLayoutContentViewModel = package.CreatePart(partUriLayoutContentViewModel, MediaTypeNames.Text.Xml, CompressionOption.Normal);
            if (package.RelationshipExists(layoutContentViewModel.PackagePartID))
            {
                package.DeleteRelationship(layoutContentViewModel.PackagePartID);
            }
            var packageRelationShipLayoutContentViewModel = package.CreateRelationship(partUriLayoutContentViewModel, TargetMode.Internal, layoutContentViewModel.PackagePartType, layoutContentViewModel.PackagePartID);
            layoutContentViewModel.SaveState(packagePartLayoutContentViewModel.GetStream());
        }
        public void Open(string fileName)
        {
            //close all other windows
            foreach (Window win in Application.Current.Windows)
            {
                if (win != Application.Current.MainWindow)
                {
                    win.Close();
                }
            }
            if (!File.Exists(fileName))
            {
                MessageBox.Show(fileName, "The File Is Not Exist!");
                return;
            }
            if (fileName.EndsWith(".meta"))
            {
                OpenMetaFile(fileName);
            }
            else
            {
                ShellService.Messager.MessageBox.ShowInformation("Please Make Sure The Extension Of Input File Is .meta");
                return;
            }

        }
        public void Save(string fileName)
        {
            try
            {
                SavePackage(fileName);
                addToRecentFiles(fileName);
                ShellService.Messager.Balloon.ShowCustomBalloon(PopupAnimation.Slide, 4000, Resources.Information, Resources.FileSavedMessage, BalloonIcon.Info);
            }
            catch (Exception e)
            {
                if (File.Exists(fileName))
                {
                    File.Delete(fileName);
                }
                if (File.Exists(fileName + ".backup"))
                {
                    File.Copy(fileName + ".backup", fileName);
                }
                MessageBox.Show("File Save Error!" + System.Environment.NewLine + e.Message + System.Environment.NewLine + e.StackTrace);
            }
        }
        #endregion
    }
}
